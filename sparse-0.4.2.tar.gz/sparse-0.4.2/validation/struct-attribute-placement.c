struct __attribute__((__aligned__(16))) foo {
    int a;
};
/*
 * check-name: struct attribute placement
 */
