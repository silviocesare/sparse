static int f(void);

int f(void)
{
	return 0;
}
/*
 * check-name: static forward declaration
 * check-known-to-fail
 */
