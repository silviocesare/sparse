static int foo(void)
{
       return 0;
rtattr_failure: __attribute__ ((unused))
       return -1;
}
/*
 * check-name: Label attribute
 */
